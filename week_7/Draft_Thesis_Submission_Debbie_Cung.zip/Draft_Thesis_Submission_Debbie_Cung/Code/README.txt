------------------------------------------------------------
PROJECT OVERVIEW
------------------------------------------------------------
This project investigates the relationship between COVID-19 testing rates and active case growth across countries using a global panel dataset.
The analysis tests the hypothesis that increased and timely testing reduces active case growth by identifying infections earlier and allowing for more effective isolation.

The project includes the following major sections:
1. Data Collection and Preprocessing – Cleans and prepares the dataset for analysis.
2. Exploratory Data Analysis (EDA) – Summarizes variable distributions and testing trends.
3. Statistical Analysis (Panel Fixed Effects) – Estimates the relationship between testing and active case growth.
4. Deeper Testing and Reliability Checks – Performs robustness checks (bootstrapping, jackknife, and placebo tests).
5. Visualizations and Insights – Generates visual summaries of testing effects and model results.

------------------------------------------------------------
DATASET INFORMATION
------------------------------------------------------------
Source: Kaggle COVID-19 Worldwide Testing Data (compiled from multiple national reports).
Variables: Includes daily tests, positive cases, active cases, recoveries, deaths, and related growth metrics.
Time Frame: February 2020 – September 2022.

Data Cleaning Steps:
- Filtered for national-level totals (Province_State == "All States").
- Removed variables with high missingness (hospitalization data).
- Replaced missing numeric values using forward and backward filling (na.locf).
- Computed 7-day rolling averages and lagged variables for regression analysis.

------------------------------------------------------------
SOFTWARE AND PACKAGES REQUIRED
------------------------------------------------------------
Install the following R packages before running the script:

install.packages(c(
  "tidyverse", "lubridate", "zoo", "fixest", "modelsummary", 
  "ggplot2", "knitr", "kableExtra", "gt", "tinytex", 
  "dplyr", "tidyr", "pandoc", "webshot2", "boot", "purrr", "tibble", "readr"
))

------------------------------------------------------------
HOW TO RUN THE PROJECT
------------------------------------------------------------
1. Open RStudio and set the working directory to the project folder:
   setwd("path_to_your_project_directory")

2. Open the main R Markdown file:
   Investigating Covid-19 Virus Trends.Rmd

3. Run all chunks sequentially, or click “Knit” → “Knit to HTML” to produce the full project report.

This will generate:
- Investigating Covid-19 Virus Trends.html – Main analysis report.
- PDFs and CSVs for intermediate outputs (figures, bootstrap summaries, regression tables).

------------------------------------------------------------
OUTPUT FILES GENERATED
------------------------------------------------------------
| Output File | Description |
|--------------|-------------|
| COVID_clean_daily_panel.csv | Cleaned dataset for analysis |
| eda_summary.pdf | Summary statistics table |
| eda_distributions.pdf | Histograms of key variables |
| eda_global_tests_vs_growth.pdf | Scaled trends of testing vs. growth |
| regression_results.pdf | Regression summary table |
| bootstrap_hist.pdf | Bootstrap estimate distribution |
| jackknife_hist.pdf | Jackknife coefficient stability |
| distributed_lag.pdf | Distributed-lag model of testing impact |
| binscatter.pdf | Within-country binned scatter plot |
| visual_insights.md | Text summary of key findings |

------------------------------------------------------------
REPRODUCIBILITY NOTES
------------------------------------------------------------
- Uses fixed effects models (feols) from the fixest package for robust estimation.
- Random seeds (set.seed(123)) ensure reproducibility of bootstrap results.
- The script automatically saves all output files to the working directory.
